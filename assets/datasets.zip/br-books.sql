CREATE TABLE livros (
	id_livro INTEGER,
	data_venda DATE,
	rank_venda FLOAT,
	nome_produto VARCHAR,
	estrelas FLOAT,
	reviews FLOAT,
	autores VARCHAR,
	edicao VARCHAR,
	preco_padrao_min FLOAT,
	preco_max FLOAT
);

COPY livros(id_livro,data_venda,rank_venda,nome_produto,estrelas,reviews,autores,edicao,preco_padrao_min,preco_max)
FROM 'C:\tmp\br-books.csv'
DELIMITER '|'
CSV HEADER;

SELECT * FROM livros;