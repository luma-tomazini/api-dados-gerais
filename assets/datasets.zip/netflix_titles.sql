CREATE TABLE IF NOT EXISTS netflix_titles(
	show_id VARCHAR PRIMARY KEY NOT NULL,
	tipo VARCHAR,
	titulo VARCHAR,
	diretor VARCHAR,
	elenco VARCHAR,
	pais VARCHAR ,
	adicionado VARCHAR ,
	ano_lancamento INTEGER,
	classificacao VARCHAR,
	duracao VARCHAR,
	listado_em VARCHAR,
	descricao VARCHAR);

COPY netflix_titles(show_id,tipo,titulo,diretor,elenco,pais,adicionado,ano_lancamento,classificacao,duracao,listado_em,descricao)
FROM 'C:\tmp\netflix_titles.csv'
DELIMITER ','
CSV HEADER;

SELECT * FROM netflix_titles;